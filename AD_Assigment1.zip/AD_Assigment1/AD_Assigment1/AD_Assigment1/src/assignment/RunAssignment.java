package assignment;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

public class RunAssignment {
    public static void main(String[] a) throws IOException, ParseException {
        /*
         *   Illustrates use of convert routine.
         */

        Scanner sc = new Scanner(new File("C:\\Users\\Andy\\Documents\\Desktop\\CAMPUS\\2021\\semester 2\\COMP 314\\COMP314_Assignment_1_2021\\COMP314_Assignment_1_2021\\TestData.txt"));
        String re = sc.nextLine();
        while(sc.hasNextLine()) {
            System.out.println("Converting regular expression " + re + " to RegExp expression tree");
            try {
                RegExp.setNextStateNum(0);
                RegExp r = (new RegExp2AST(re)).convert();
                System.out.println("No syntax errors");
                System.out.println("Original fully parenthesised regular expression : " +
                        r.decompile());
                System.out.println("\nConverting regular expression " + re + " to NFA");
                Nfa n = r.makeNfa();
                System.out.println("ksdanfsdnfkjKNSFLWENFJNSC NSDFWFDSJSD SDNF SLSBFSD FOSDAIFNSD OINDSF ODS FOS DF");

                System.out.println(n);
            }
            catch (ParseException ex) {
                System.out.println("Error at/near position " + ex.getErrorOffset() + " : " + ex.getMessage());
            }
            
            String testData = sc.nextLine();
            while (!testData.equals("//")){
                /* to test if each
                /* each string belongs to the current language;
                * */
                System.out.println("Test for "+testData+" in language"+re);
                //we will edit this when we have the a code to test with

                testData = sc.nextLine();
                
        dfa = new Dfa(nfa);
        System.out.println(dfa);
        System.out.println("===================================\n");
        
        //Test a string using the DFA above
        System.out.println("Enter a string to test, 0 to exit: \n");
        String testString = sc.next();
        if(!testString.equals("//")){
            do{
                if(dfa.acceptString(testString)){
                	System.out.println("STRING: '"+testString+"' IS ACCEPTED!!\n");
                }
                else{
                	System.out.println("STRING: '"+testString+"' IS REJECTED!!\n");
                }  
                System.out.println("Enter a string to test, 0 to exit: ");
                testString = sc.next();
            }
            while(!testString.equals("//"));
        }
            }
            if(sc.hasNextLine())
                re = sc.nextLine();
            System.out.println();
        }
        sc.close();

    }
}
